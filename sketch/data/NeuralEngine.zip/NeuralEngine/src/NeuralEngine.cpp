#include "NeuralEngine.h"

#include <HTTPClient.h>
#include <esp_system.h>
#include <EEPROM.h>
#include <ctype.h>
#include <string.h>

/* ================= API CONFIG ================= */
static const char* CL_API =
"https://www.skynetbee.com/skynetbee/api/iot/esp32/logs_get.php";

/* ================= FIXED PARAMS ================= */
static const char* PRONI_PROJECT_NICHE = "IoT";
static const char* PROJECT_NAME = "Kishore";
static const char* ROOM_NAME = "Stark_Industries";
static const char* CLASS_NAME = "MyClass";
static const char* LOG_TYPE = "info";
static const char* AREA = "Erode";

/* ================= EEPROM ================= */
#define EEPROM_SIZE 1024
#define START_ADDR 4

/* ================= ESP HARDWARE ID ================= */
String getESP_ID() {
    uint64_t chipid = ESP.getEfuseMac();
    char id[17];
    sprintf(id, "%04X%08X",
            (uint16_t)(chipid >> 32),
            (uint32_t)chipid);
    return String(id);
}

/* ================= URL ENCODE ================= */
static String _cl_encode(const String &s) {
    String out = "";
    char buf[4];
    for (char c : s) {
        if (isalnum(c) || c=='_' || c=='-' || c=='.' || c==' ')
            out += c;
        else {
            sprintf(buf, "%%%02X", (unsigned char)c);
            out += buf;
        }
    }
    return out;
}

/* ================= CORE SENDER ================= */
void _cl_send(
    const char* file,
    const char* func,
    int line,
    const String &msg
) {
    if (msg.length()) Serial.println(msg);
    if (WiFi.status() != WL_CONNECTED) return;

    HTTPClient http;
    String url = String(CL_API) +
        "?proniproject_niche=" + PRONI_PROJECT_NICHE +
        "&project_name=" + PROJECT_NAME +
        "&room_name=" + ROOM_NAME +
        "&esp_id=" + getESP_ID() +
        "&file_name=" + _cl_encode(file) +
        "&class_name=" + CLASS_NAME +
        "&function_name=" + func +
        "&line_number=" + String(line) +
        "&log_type=" + LOG_TYPE +
        "&message=" + _cl_encode(msg) +
        "&area=" + AREA +
        "&pin_device_config=[]" +
        "&deviceanduserinfo=[]";

    http.begin(url);
    http.GET();
    http.end();
}

/* ================= SERIAL ================= */
void clearSerialBuffer(void) {
    while (Serial.available()) Serial.read();
}

static void readLine(char *buf, int maxLen) {
    int i = 0;
    while (!Serial.available());
    while (Serial.available()) {
        char c = Serial.read();
        if (c == '\n' || c == '\r') break;
        if (i < maxLen - 1) buf[i++] = c;
    }
    buf[i] = '\0';
}

int readInt(void) {
    clearSerialBuffer();
    char buf[16];
    readLine(buf, sizeof(buf));
    return atoi(buf);
}

void readString(char *buffer, int maxLen) {
    clearSerialBuffer();
    readLine(buffer, maxLen);
}

char readChar(void) {
    clearSerialBuffer();
    while (!Serial.available());
    return Serial.read();
}

float readFloat(void) {
    clearSerialBuffer();
    char buf[20];
    readLine(buf, sizeof(buf));
    return atof(buf);
}

double readDouble(void) {
    clearSerialBuffer();
    char buf[32];
    readLine(buf, sizeof(buf));
    return atof(buf);
}

/* ================= EEPROM ================= */
static void initEEP() {
    static bool init = false;
    if (!init) {
        EEPROM.begin(EEPROM_SIZE);
        init = true;
    }
}

static int readLength() {
    int len = 0;
    for (int i = 0; i < 4; i++)
        len |= EEPROM.read(i) << (8 * i);
    return len;
}

static void saveLength(int length) {
    for (int i = 0; i < 4; i++)
        EEPROM.write(i, (length >> (8 * i)) & 0xFF);
    EEPROM.commit();
}

void set_item(const char *key, const char *value) {
    initEEP();
    int len = readLength();
    int pos = START_ADDR + len;

    int needed = strlen(key) + strlen(value) + 2;
    if (pos + needed >= EEPROM_SIZE) return;

    while (*key) EEPROM.write(pos++, *key++);
    EEPROM.write(pos++, '\0');

    while (*value) EEPROM.write(pos++, *value++);
    EEPROM.write(pos++, '\0');

    saveLength(len + needed);
}

char* get_item(const char *key) {
    static char out[64];
    initEEP();

    int len = readLength();
    int pos = START_ADDR;

    while (pos < START_ADDR + len) {
        char temp[32];
        int i = 0;

        while (EEPROM.read(pos) != '\0')
            temp[i++] = EEPROM.read(pos++);
        temp[i] = '\0';
        pos++;

        if (strcmp(temp, key) == 0) {
            i = 0;
            while (EEPROM.read(pos) != '\0' && i < 63)
                out[i++] = EEPROM.read(pos++);
            out[i] = '\0';
            return out;
        }

        while (EEPROM.read(pos) != '\0') pos++;
        pos++;
    }
    return NULL;
}

void clearEEP(void) {
    initEEP();
    for (int i = 0; i < EEPROM_SIZE; i++) EEPROM.write(i, 0);
    saveLength(0);
}
