#include <WiFi.h>
#include <NeuralEngine.h>

const char* ssid = "hello";
const char* password = "hello123";

void setup() {
  Serial.begin(115200);

  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) delay(500);

  cl("NeuralEngine Library Test");
//   cl("ESP ID:", getESP_ID().c_str());

  set_item("name", "NeuralEngine");
  cl("EEPROM name:", get_item("name"));
}

void loop() {
//   cl("Heartbeat");
//   delay(10000);
}
